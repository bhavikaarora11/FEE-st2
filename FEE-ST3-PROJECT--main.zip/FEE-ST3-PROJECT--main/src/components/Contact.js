

import React from "react";
 import { Group6}  from "./Group6";
 import  {Navbar}  from "./Navbar";
import { Footer } from "./Footer";


 export const Contact = ()=>{
    return(<>
    <Navbar />
    <div className="routecontact">
    <Group6 />
    </div>
    <Footer />
    </>)
}
