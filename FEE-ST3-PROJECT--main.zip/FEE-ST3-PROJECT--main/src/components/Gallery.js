import { Group4 } from "./Group4";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
const Gallery =()=>{
    return(<>
       <Navbar/>
       <Group4/>
       <Footer/>
    </>)
}

export default Gallery