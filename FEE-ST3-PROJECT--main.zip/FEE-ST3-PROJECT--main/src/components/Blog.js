
import { Navbar } from "./Navbar";
import { Group7 } from "./Group7";
import { Group8 } from "./Group8";


const About = ()=>{
    return(<>
   
   <Navbar/>
    <Group7/>
    <Group8/>
    </>)
}

export default About 