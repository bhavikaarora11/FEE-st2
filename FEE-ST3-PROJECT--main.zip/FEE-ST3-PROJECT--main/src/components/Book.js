import { Group5 } from "./Group5";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
const Booking = () => {
  return (
    <>
      <Navbar />
      <Group5 />
      <Footer />
    </>
  );
};

export default Booking;
