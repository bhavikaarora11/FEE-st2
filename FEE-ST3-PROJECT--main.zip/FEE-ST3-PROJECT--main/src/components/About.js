
import { Navbar } from "./Navbar";
import { Group2 } from "./Group2";
import { Footer } from "./Footer";


const About = ()=>{
    return(<>
   
   <Navbar/>
    <Group2/>
    <Footer/>
    </>)
}

export default About 